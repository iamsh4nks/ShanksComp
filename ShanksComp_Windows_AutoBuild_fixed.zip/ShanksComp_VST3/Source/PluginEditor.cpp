#include "PluginEditor.h"

ShanksCompAudioProcessorEditor::ShanksCompAudioProcessorEditor(ShanksCompAudioProcessor& p)
    : AudioProcessorEditor(&p), processor(p)
{
    setSize(620, 330);
    for (size_t i = 0; i < knobs.size(); ++i)
    {
        knobs[i] = std::make_unique<Slider>();
        knobs[i]->setSliderStyle(Slider::RotaryHorizontalVerticalDrag);
        knobs[i]->setTextBoxStyle(Slider::TextBoxBelow, false, 76, 20);
        knobs[i]->setColour(Slider::rotarySliderFillColourId, juce::Colour(0xffffc928));
        knobs[i]->setColour(Slider::rotarySliderOutlineColourId, juce::Colour(0xff34343a));
        knobs[i]->setColour(Slider::thumbColourId, juce::Colour(0xffffffff));
        addAndMakeVisible(*knobs[i]);

        labels[i] = std::make_unique<juce::Label>();
        labels[i]->setText(names[i], juce::dontSendNotification);
        labels[i]->setJustificationType(juce::Justification::centred);
        labels[i]->setColour(juce::Label::textColourId, juce::Colour(0xffeeeeee));
        labels[i]->setFont(juce::Font(11.0f, juce::Font::bold));
        addAndMakeVisible(*labels[i]);

        attachments[i] = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(
            processor.parameters, ids[i], *knobs[i]);
    }
}

void ShanksCompAudioProcessorEditor::paint(juce::Graphics& g)
{
    g.fillAll(juce::Colour(0xff111116));
    g.setColour(juce::Colour(0xffffc928));
    g.fillRoundedRectangle(18.0f, 18.0f, 584.0f, 5.0f, 2.0f);
    g.setColour(juce::Colours::white);
    g.setFont(juce::Font(27.0f, juce::Font::bold));
    g.drawText("SHANKSCOMP", 24, 34, 572, 38, juce::Justification::centredLeft);
    g.setColour(juce::Colour(0xffa7a7ae));
    g.setFont(13.0f);
    g.drawText("VOCAL / BUS COMPRESSOR", 26, 70, 400, 20, juce::Justification::centredLeft);
    g.setColour(juce::Colour(0xff292930));
    g.drawRoundedRectangle(18.0f, 105.0f, 584.0f, 205.0f, 12.0f, 1.0f);
    g.setColour(juce::Colour(0xff777780));
    g.setFont(11.0f);
    g.drawText("sh4nks!  |  V1.0", 430, 72, 160, 18, juce::Justification::centredRight);
}

void ShanksCompAudioProcessorEditor::resized()
{
    const int left = 28, top = 118, width = 564, cell = width / 4;
    for (int i = 0; i < 7; ++i)
    {
        const int row = i / 4;
        const int col = i % 4;
        const int x = left + col * cell;
        const int y = top + row * 96;
        knobs[(size_t)i]->setBounds(x + 16, y + 2, 108, 76);
        labels[(size_t)i]->setBounds(x + 8, y + 76, 124, 18);
    }
}
