#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"

class ShanksCompAudioProcessorEditor : public juce::AudioProcessorEditor
{
public:
    explicit ShanksCompAudioProcessorEditor(ShanksCompAudioProcessor&);
    ~ShanksCompAudioProcessorEditor() override = default;
    void paint(juce::Graphics&) override;
    void resized() override;

private:
    using Slider = juce::Slider;
    ShanksCompAudioProcessor& processor;
    std::array<std::unique_ptr<Slider>, 7> knobs;
    std::array<std::unique_ptr<juce::Label>, 7> labels;
    std::array<std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>, 7> attachments;
    const std::array<const char*, 7> ids { "threshold", "ratio", "attack", "release", "knee", "makeup", "mix" };
    const std::array<const char*, 7> names { "THRESHOLD", "RATIO", "ATTACK", "RELEASE", "KNEE", "MAKEUP", "MIX" };
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(ShanksCompAudioProcessorEditor)
};
