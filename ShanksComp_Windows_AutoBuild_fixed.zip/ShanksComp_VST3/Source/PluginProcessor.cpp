#include "PluginProcessor.h"
#include "PluginEditor.h"

ShanksCompAudioProcessor::ShanksCompAudioProcessor()
    : AudioProcessor(BusesProperties()
        .withInput("Input", juce::AudioChannelSet::stereo(), true)
        .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      parameters(*this, nullptr, "PARAMETERS", createParameterLayout())
{
}

juce::AudioProcessorValueTreeState::ParameterLayout ShanksCompAudioProcessor::createParameterLayout()
{
    using Float = juce::AudioParameterFloat;
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> p;
    p.push_back(std::make_unique<Float>("threshold", "Threshold",
        juce::NormalisableRange<float>(-48.0f, 0.0f, 0.1f), -18.0f));
    p.push_back(std::make_unique<Float>("ratio", "Ratio",
        juce::NormalisableRange<float>(1.0f, 20.0f, 0.1f), 3.0f));
    p.push_back(std::make_unique<Float>("attack", "Attack",
        juce::NormalisableRange<float>(0.1f, 100.0f, 0.1f, 0.5f), 10.0f));
    p.push_back(std::make_unique<Float>("release", "Release",
        juce::NormalisableRange<float>(10.0f, 1000.0f, 1.0f, 0.5f), 100.0f));
    p.push_back(std::make_unique<Float>("knee", "Knee",
        juce::NormalisableRange<float>(0.0f, 12.0f, 0.1f), 6.0f));
    p.push_back(std::make_unique<Float>("makeup", "Makeup",
        juce::NormalisableRange<float>(-12.0f, 24.0f, 0.1f), 0.0f));
    p.push_back(std::make_unique<Float>("mix", "Mix",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 100.0f));
    return { p.begin(), p.end() };
}

bool ShanksCompAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const
{
    const auto in = layouts.getMainInputChannelSet();
    const auto out = layouts.getMainOutputChannelSet();
    return in == out && (out == juce::AudioChannelSet::mono() || out == juce::AudioChannelSet::stereo());
}

void ShanksCompAudioProcessor::prepareToPlay(double sampleRate, int)
{
    currentSampleRate = sampleRate;
    envelope = 0.0f;
}

void ShanksCompAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;
    const int channels = buffer.getNumChannels();
    const int samples = buffer.getNumSamples();

    const float threshold = parameters.getRawParameterValue("threshold")->load();
    const float ratio = parameters.getRawParameterValue("ratio")->load();
    const float attackMs = parameters.getRawParameterValue("attack")->load();
    const float releaseMs = parameters.getRawParameterValue("release")->load();
    const float kneeDb = parameters.getRawParameterValue("knee")->load();
    const float makeupDb = parameters.getRawParameterValue("makeup")->load();
    const float mix = parameters.getRawParameterValue("mix")->load() * 0.01f;

    const float attackCoeff = std::exp(-1.0f / (float(currentSampleRate) * attackMs * 0.001f));
    const float releaseCoeff = std::exp(-1.0f / (float(currentSampleRate) * releaseMs * 0.001f));
    const float makeup = juce::Decibels::decibelsToGain(makeupDb);

    for (int i = 0; i < samples; ++i)
    {
        float peak = 0.0f;
        for (int ch = 0; ch < channels; ++ch)
            peak = juce::jmax(peak, std::abs(buffer.getSample(ch, i)));

        const float coeff = peak > envelope ? attackCoeff : releaseCoeff;
        envelope = coeff * envelope + (1.0f - coeff) * peak;

        const float levelDb = juce::Decibels::gainToDecibels(envelope + 1.0e-9f);
        const float over = levelDb - threshold;
        float reductionDb = 0.0f;

        if (kneeDb > 0.0f && over > -kneeDb * 0.5f && over < kneeDb * 0.5f)
        {
            const float x = over + kneeDb * 0.5f;
            reductionDb = (1.0f / ratio - 1.0f) * x * x / (2.0f * kneeDb);
        }
        else if (over >= kneeDb * 0.5f)
            reductionDb = (1.0f / ratio - 1.0f) * over;

        const float gain = juce::Decibels::decibelsToGain(reductionDb) * makeup;

        for (int ch = 0; ch < channels; ++ch)
        {
            const float dry = buffer.getSample(ch, i);
            const float wet = dry * gain;
            buffer.setSample(ch, i, dry * (1.0f - mix) + wet * mix);
        }
    }
}

juce::AudioProcessorEditor* ShanksCompAudioProcessor::createEditor()
{
    return new ShanksCompAudioProcessorEditor(*this);
}

void ShanksCompAudioProcessor::getStateInformation(juce::MemoryBlock& destData)
{
    auto state = parameters.copyState();
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, destData);
}

void ShanksCompAudioProcessor::setStateInformation(const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xml(getXmlFromBinary(data, sizeInBytes));
    if (xml != nullptr && xml->hasTagName(parameters.state.getType()))
        parameters.replaceState(juce::ValueTree::fromXml(*xml));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new ShanksCompAudioProcessor();
}
